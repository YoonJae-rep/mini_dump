
#define SECURITY_WIN32
#include <sspi.h>
