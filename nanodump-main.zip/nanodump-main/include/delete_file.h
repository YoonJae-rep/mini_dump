#pragma once

#include "utils.h"
#include "syscalls.h"
#include "nanodump.h"
#include "beacon.h"

VOID do_delete(
    IN LPSTR file_path);
